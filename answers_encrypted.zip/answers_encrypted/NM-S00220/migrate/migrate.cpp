#include<bits/stdc++.h>
using namespace std;


int main(){
	freopen("migrate.in","r",stdin);
	freopen("migrate.out","w",stdout);
	cout<<1<<endl<<1<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
