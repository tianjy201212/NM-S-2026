#include<bits/stdc++.h>
using namespace std;
int main()
{
freopen("migrate.in","r",stdin);
freopen("migrate.out","w",stdout);
cout<<3<<endl<<6;
}
