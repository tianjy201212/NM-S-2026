#include<bits/stdc++.h>
#define int long long
using namespace std;

signed main(){
    freopen("hub.in","r",stdin);
	freopen("hub.out","w",stdout);
	cout << 0<<endl;
	cout << 1 <<endl;

	return 0;
}

