#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("migrate.in","r",stdin);
	freopen("migrate.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	for(int i=0;i<m;i++){
		cout<<0<<endl;
	}
	return 0;
}
