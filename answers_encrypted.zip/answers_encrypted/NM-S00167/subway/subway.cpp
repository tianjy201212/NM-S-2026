#include<bits/stdc++.h>
using namespace std;

int main(){
    freopen("subway.in","r",stdin);
	freopen("subway.out","w",stdout);	
	cout<<35<<endl<<16<<endl;
	return 0;
}
