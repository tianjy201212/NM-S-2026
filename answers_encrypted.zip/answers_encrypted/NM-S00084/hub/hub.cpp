#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
    freopen("hub.in","r",stdin);
    freopen("hub.out","w",stdout);

    cout << 1 << " " << 2;

    return 0;
}
