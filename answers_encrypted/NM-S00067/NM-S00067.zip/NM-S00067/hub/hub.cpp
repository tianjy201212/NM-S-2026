#include<bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	freopen("hub.in","r",stdin);
	freopen("hub.out","w",stdout);
	return 0;
}
/*
..000..
.0...0.
....0..
...0...
...0...
.......
...0...
*/
